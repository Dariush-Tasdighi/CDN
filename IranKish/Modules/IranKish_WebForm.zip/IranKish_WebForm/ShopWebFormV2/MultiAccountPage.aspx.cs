﻿using System;
using System.Configuration;
using System.Web.UI;
using System.Collections.Generic;
using System.Data;
using System.Xml;
using Newtonsoft.Json;

namespace ShopWebForm
{
    public partial class MultiAccountPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // txtAmount.Text = "1000";

                DataSet shebaList = new DataSet();
                shebaList.ReadXml(Server.MapPath("DataXmlFile.xml"));

                DropDownList0.DataSource = shebaList.Tables["Shebalist"];
                DropDownList0.DataTextField = "Sheba";
                DropDownList0.DataValueField = "name";
                DropDownList0.DataBind();

                DropDownList1.DataSource = shebaList.Tables["Shebalist"];
                DropDownList1.DataTextField = "Sheba";
                DropDownList1.DataValueField = "Name";
                DropDownList1.DataBind();

                InitialTextBox();
  
            }
        }

        protected void getToken_Click(object sender, EventArgs e)
        {

            try
            {

                WebHelper webHelper = new WebHelper();

                string paymetId = new Random().Next().ToString();
                string requestId = new Random().Next().ToString();
                string request = string.Empty;
                int totalAmount = 0;
                XmlDocument doc = new XmlDocument();

                doc.Load(Server.MapPath("DataXmlFile.xml"));
                IPGData iPGData = new IPGData();
                iPGData.TreminalId = txtTerminalId.Text;
                iPGData.AcceptorId = txtAcceptorID.Text;
                iPGData.PassPhrase = txtPassPhrase.Text;
                iPGData.RevertURL = doc.SelectNodes("DocumentElement/IPGData")[0].SelectNodes("URL")[0].InnerText;
               
                iPGData.PaymentId = paymetId;
                iPGData.RequestId = requestId;
                iPGData.CmsPreservationId = doc.SelectNodes("DocumentElement/IPGData")[0].SelectNodes("CmsPreservationId")[0].InnerText; ;
                iPGData.TransactionType = TransactionType.Purchase;
                iPGData.BillInfo = null;

                List<MultiplexParameter> multiplexParameters = new List<MultiplexParameter>();

                if (!string.IsNullOrEmpty(txtAmount1.Text))
                {
                    MultiplexParameter account1 = new MultiplexParameter();
                    account1.Amount = int.Parse(txtAmount1.Text);
                    account1.Iban = DropDownList0.SelectedItem.Text;
                    multiplexParameters.Add(account1);
                    totalAmount += int.Parse(txtAmount1.Text);

                }
                if (!string.IsNullOrEmpty(txtAmount2.Text))
                {
                    MultiplexParameter account1 = new MultiplexParameter();
                    account1.Amount = int.Parse(txtAmount2.Text);
                    account1.Iban = DropDownList1.SelectedItem.Text; 
                    multiplexParameters.Add(account1);
                    totalAmount += int.Parse(txtAmount2.Text);
                }
                iPGData.MultiplexParameters = multiplexParameters;
                txtAmount.Text = totalAmount.ToString();
                iPGData.Amount = long.Parse(txtAmount.Text);
                iPGData.RsaPublicKey = doc.SelectNodes("DocumentElement/IPGData/RSAPublicKey")[0].InnerXml.ToString();
                request = CreateJsonRequest.CreateJasonRequest(iPGData);
 
                Uri url = new Uri(doc.SelectNodes("DocumentElement/BaseAddress/token")[0].InnerXml.ToString());
                string jresponse = webHelper.Post(url, request);

                if (jresponse != null)
                {
                    TokenResult jResult = JsonConvert.DeserializeObject<TokenResult>(jresponse);
                    //Handle your reponse here 
                    if (jResult.status)
                    {
                        txtToken.Text = jResult.result?.token;
                        //Literal2.Text = string.Format("<input id='token' type='hidden'  name='tokenIdentity' value='{0}' runat='server' />", txtToken.Text);
                        Response.Clear();
                        XmlNodeList xnList = doc.SelectNodes("DocumentElement/BaseAddress/payment");
                        var urlpayment = xnList[0].InnerXml.ToString();
                        var sb = new System.Text.StringBuilder();
                        sb.Append("<html>");
                        sb.AppendFormat("<body onload='document.forms[0].submit()'>");
                        sb.AppendFormat("<form action='{0}' method='post'>", urlpayment);

                        sb.AppendFormat("<input type='hidden' name='tokenIdentity' value='{0}'>", txtToken.Text);
                        sb.Append("</form>");
                        sb.Append("</body>");
                        sb.Append("</html>");
                        Response.Write(sb.ToString());
                    }
                    else
                    {
                        txtToken.Text = string.Format("result:{0} desc:{1}", jResult.responseCode, jResult.description);
                    }
                }
              
            }
            catch (Exception exe)
            {
                txtToken.Text = exe.Message;
            }
        }

        protected void drpSheba1_TextChanged(object sender, EventArgs e)
        {
            string controlId = ((System.Web.UI.Control)sender).UniqueID;
            switch (((System.Web.UI.Control)sender).ID)
            {
                case "DropDownList0":
                    Label0.Text = ((System.Web.UI.WebControls.ListControl)sender).SelectedValue;
                    break;
                case "DropDownList1":
                    Label1.Text = ((System.Web.UI.WebControls.ListControl)sender).SelectedValue;
                    break;
                //case "DropDownList2":
                //    Label2.Text = ((System.Web.UI.WebControls.ListControl)sender).SelectedValue;
                //    break;
                //case "DropDownList3":
                //    Label3.Text = ((System.Web.UI.WebControls.ListControl)sender).SelectedValue;
                //    break;
                default:
                    break;
            }
            // shebaName.Text = ((System.Web.UI.WebControls.ListControl)sender).SelectedValue;
        }

        private void InitialTextBox()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(Server.MapPath("DataXmlFile.xml"));
            //Get URL
            XmlNode elemList = doc.GetElementsByTagName("IPGData").Item(0);
            txtTerminalId.Text = elemList.ChildNodes[0].InnerText;
            txtAcceptorID.Text = elemList.ChildNodes[1].InnerText;
            txtPassPhrase.Text = elemList.ChildNodes[2].InnerText;
             
        }
    }
}