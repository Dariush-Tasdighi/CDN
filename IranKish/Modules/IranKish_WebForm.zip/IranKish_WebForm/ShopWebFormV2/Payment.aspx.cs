﻿
using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Xml;
using Newtonsoft.Json;

namespace ShopWebForm
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                txtAmount.Text = "1000";
                InitialTextBox();
            }
        }

        private void InitialTextBox()
        {
            XmlDocument doc = new XmlDocument();

            doc.Load(Server.MapPath("DataXmlFile.xml"));

            XmlNodeList xnList = doc.SelectNodes("DocumentElement/IPGData/RSAPublicKey");
            string d = xnList[0].InnerXml.ToString();
            doc.Load(Server.MapPath("DataXmlFile.xml"));
            //Get URL
            XmlNode elemList = doc.GetElementsByTagName("IPGData").Item(0);
            txtTerminalId.Text = elemList.ChildNodes[0].InnerText;
            txtAcceptorID.Text = elemList.ChildNodes[1].InnerText;
            txtPassPhrase.Text = elemList.ChildNodes[2].InnerText;
            // txtRevertUri.Text = elemList.ChildNodes[3].InnerText;
        }

        protected void getToken_onclick(object sender, EventArgs e)
        {
            try
            {
                WebHelper webHelper = new WebHelper();
                XmlDocument doc = new XmlDocument();

                doc.Load(Server.MapPath("DataXmlFile.xml"));

                string paymetId = new Random().Next().ToString();
                string requestId = new Random().Next().ToString();
                string request = string.Empty;
                IPGData iPGData = new IPGData();
                iPGData.TreminalId = txtTerminalId.Text;
                iPGData.AcceptorId = txtAcceptorID.Text;

                iPGData.RevertURL = doc.SelectNodes("DocumentElement/IPGData")[0].SelectNodes("URL")[0].InnerText;
                iPGData.Amount = long.Parse(txtAmount.Text);
                iPGData.PaymentId = paymetId;
                iPGData.RequestId = requestId;
                iPGData.CmsPreservationId = doc.SelectNodes("DocumentElement/IPGData")[0].SelectNodes("CmsPreservationId")[0].InnerText;
                iPGData.TransactionType = TransactionType.Purchase;
                iPGData.BillInfo = null;
                iPGData.PassPhrase = txtPassPhrase.Text;
                iPGData.RsaPublicKey = doc.SelectNodes("DocumentElement/IPGData/RSAPublicKey")[0].InnerXml.ToString(); ;

                request = CreateJsonRequest.CreateJasonRequest(iPGData);

                Uri url = new Uri(doc.SelectNodes("DocumentElement/BaseAddress/token")[0].InnerXml.ToString());
                string jresponse = webHelper.Post(url, request);

                if (jresponse != null)
                {
                    TokenResult jResult = JsonConvert.DeserializeObject<TokenResult>(jresponse);
                    //Handle your reponse here 

                    if (jResult.status)
                    {
                        txtToken.Text = jResult.result?.token;
                        // tblForm.Visible = true;
                        //Literal2.Text = string.Format("<input id='token' type='hidden' name='tokenIdentity' value='{0}' runat='server'/>", txtToken.Text);
                        Response.Clear();
                        XmlNodeList xnList = doc.SelectNodes("DocumentElement/BaseAddress/payment");
                        var urlpayment = xnList[0].InnerXml.ToString();
                        var sb = new System.Text.StringBuilder();
                        sb.Append("<html>");
                        sb.AppendFormat("<body onload='document.forms[0].submit()'>");
                        sb.AppendFormat("<form action='{0}' method='post'>", urlpayment);

                        sb.AppendFormat("<input type='hidden' name='tokenIdentity' value='{0}'>", txtToken.Text);
                        sb.Append("</form>");
                        sb.Append("</body>");
                        sb.Append("</html>");
                        Response.Write(sb.ToString());
                    }
                    else
                    {
                        txtToken.Text = string.Format("result:{0} desc:{1}", jResult.responseCode, jResult.description);
                    }
                }




            }
            catch (Exception exe)
            {

                txtToken.Text = exe.Message;
            }
        }


    }


}