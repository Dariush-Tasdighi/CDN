﻿using Microsoft.AspNetCore.Http;
using ShopWebFormV3.Models;
using System.Threading.Tasks;

namespace ShopWebFormV3.DAL.Interface
{
    public interface IVerification
    {

        Task<string> btnVerification_Click(RequestVerify requestVerify);
    }
}
