﻿using Microsoft.AspNetCore.Http;
using ShopWebFormV3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopWebFormV3.DAL
{
     public interface IIPGRepository 
    {
        Task<string> getToken_onclick(IPGDataModel iPGData,HttpContext httpContext);

    }
}
