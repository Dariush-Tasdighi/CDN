﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using ShopWebFormV3.DAL.Utility;
using ShopWebFormV3.Models;
using System;
using System.Collections.Generic;
using System.Xml;
using CoreApiResponse;
using System.Net.Http;
using System.Web;
using System.Threading.Tasks;


namespace ShopWebFormV3.DAL
{
    public class IPGRepository : BaseController,IIPGRepository
    {



        // خرید عادی
        public async Task<string> getToken_onclick(IPGDataModel iPGData,HttpContext httpContext)
        {

            XmlDocument doc = new XmlDocument();
            WebHelper webHelper = new WebHelper();
            string Text = string.Empty;


            try
            {


                doc.Load("DataXmlFile.xml");

                string paymentId = new Random().Next().ToString();
                string requestId = new Random().Next().ToString();
                string request = string.Empty;
                IPGDataModel _iPGData = new IPGDataModel();
                _iPGData.TerminalId = iPGData.TerminalId;
                _iPGData.AcceptorId = iPGData.AcceptorId;
               
                //آدرس برگشت اینجا ست می شود
                _iPGData.RevertURL = doc.SelectNodes("DocumentElement/IPGData")[0].SelectNodes("URL")[0].InnerText;
                _iPGData.Amount = iPGData.Amount;
                _iPGData.PaymentId = paymentId;
                _iPGData.RequestId = requestId;
              
                //the url that must be hard coded
                _iPGData.CmsPreservationId = doc.SelectNodes("DocumentElement/IPGData")[0].SelectNodes("CmsPreservationId")[0].InnerText;
                _iPGData.TransactionType = TransactionType.Purchase;
                _iPGData.BillInfo = null;
                _iPGData.PassPhrase = iPGData.PassPhrase;
               

                // کلید عمومی 
                _iPGData.RsaPublicKey = doc.SelectNodes("DocumentElement/IPGData/RSAPublicKey")[0].InnerXml.ToString(); ;


                /// call json request 
                request = CreateJsonRequest.CreateJasonRequest(_iPGData);



                string url = doc.SelectNodes("DocumentElement/BaseAddress/token")[0].InnerXml.ToString();

                // پاس دادن اطلاعات ورودی به api
                string jresponse = await webHelper.Post(url, request);

                TokenResult jResult = JsonConvert.DeserializeObject<TokenResult>(jresponse);



                  string Token = jResult.result?.token;

             

                   if (jresponse != null)
                    {
                        Text = string.Format("result:{0} desc:{1}", jResult.responseCode, jResult.description);

                        switch (jResult.responseCode)
                        {
                            case "901":

                            
                            Text = String.Format(" درخواست نا معتبر است  {0}", jResult.responseCode);



                            break;

                            case "902":


                           
                            Text = String.Format(" پارامترهای اضافی درخواست نامعتبر می باشد  {0}", jResult.responseCode);

                            break;

                            case "903":


                            
                            Text = String.Format(" شناسه پرداخت نامعتبر می باشد {0}", jResult.responseCode);

                            break;
                            case "904":


                            
                            Text = String.Format(" اطلاعات مرتبط با قبض نا معتبر می باشد {0}", jResult.responseCode);

                            break;

                            case "905":


                               
                           
                            Text = String.Format(" شناسه درخواست نامعتبر می باشد {0}", jResult.responseCode);

                            break;
                            case "906":



                            Text = String.Format(" درخواست تاریخ گذشته است {0}", jResult.responseCode);

                            break;
                            case "907":


                            Text = String.Format(" آدرس بازگشت نتیجه پرداخت نامعتبر می باشد {0}", jResult.responseCode);

                            break;

                            case "909":

                                
                            Text = String.Format(" پذیرنده نامعتبر می باشد {0}", jResult.responseCode);

                            break;


                            case "910":


                            Text = String.Format(" پارامترهای مورد انتشار پرداخت تسهیمی تامین نگردیده است {0}", jResult.responseCode);

                            break;


                            case "911":


                            Text = String.Format(" پارامترهای مورد انتشار پرداخت تسهیمی نا معتبر یا دارای اشکال می باشد {0}", jResult.responseCode);

                            break;


                            case "912":

                           
                            Text = String.Format(" تراکنش درخواستی برای پذیرنده فعال نیست {0}", jResult.responseCode);

                            break;


                            case "913":

                            
                            Text = String.Format(" تراکنش تسهیم برای پذیرنده  فعال نیست {0}", jResult.responseCode);

                            break;



                            case "914":

                            
                            Text = String.Format("  آدرس آی پی دریافتی درخواست نا معتبر می باشد {0}", jResult.responseCode);

                            break;


                            case "915":

                            
                            Text = String.Format("   شماره پایانه نامعتبر می باشد {0}", jResult.responseCode);

                            break;



                            case "916":

                             
                            Text = String.Format("   شماره پذیرنده نا معتبر می باشد {0}", jResult.responseCode);

                            break;



                            case "917":

                            
                            Text = String.Format("   نوع تراکنش اعلام شده در خواست نا معتبر می باشد {0}", jResult.responseCode);

                            break;




                            case "918":

                       
                            Text = String.Format("   پذیرنده فعال نیست {0}", jResult.responseCode);

                            break;



                            case "919":

                            
                            Text = String.Format("   مبالغ تسهیمی ارائه شده با توجه به قوانین حاکم بر وضعیت تسهیم پذیرنده ، نا معتبر است {0}", jResult.responseCode);

                            break;


                            case "920":

                                
                            Text = String.Format("   شناسه نشانه نامعتبر می باشد {0}", jResult.responseCode);   

                            break;

                            case "921":

                           
                            Text = String.Format("   شناسه نشانه نامعتبر و یا منقضی شده است {0}", jResult.responseCode);

                            break;

                            case "922":

                            
                            Text = String.Format(" نقض امنیت درخواست  {0}", jResult.responseCode);

                            break;



                            case "923":

                            
                            Text = String.Format(" ارسال شناسه پرداخت در تراکنش قبض مجاز نیست  {0}", jResult.responseCode);


                            break;



                            case "928":

                            
                            Text = String.Format(" مبلغ مبادله شده نا معتبر می باشد  {0}", jResult.responseCode);

                            break;



                            case "929":

                            
                            Text = String.Format(" شناسه پرداخت ارائه شده با توجه به الگوریتم متناظر نا معتبر می باشد  {0}", jResult.responseCode);

                            break;



                            case "930":

                          
                            Text = String.Format(" کد ملی ارائه شده نا معتبر می باشد  {0}", jResult.responseCode);

                            break;

                        case "96":

                            
                            Text = String.Format(" General failure  {0}", jResult.responseCode);


                            break;
                        }




                    }

             
                return (Token != null) ? Token : Text;






            }
            catch (Exception ex)
            {

                throw ex;
            }

          

        }


    }
}
