﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopWebFormV3.Models
{
    public class MultiplexParameter
    {

        public string Iban { get; set; }

        public int Amount { get; set; }

    }
}
