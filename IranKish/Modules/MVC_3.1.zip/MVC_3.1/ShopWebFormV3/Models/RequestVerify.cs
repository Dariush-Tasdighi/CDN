﻿using System.Runtime.Serialization;

namespace ShopWebFormV3.Models
{
    public class RequestVerify
    {

        [DataMember]
        //شماره ترمینال
        public string terminalId { get; set; }

        [DataMember]
        //شماره ارجاع
        public string retrievalReferenceNumber { get; set; }

        [DataMember]
        //شماره سند/ پیگیری
        public string systemTraceAuditNumber { get; set; }

        [DataMember]
        //توکن
        public string tokenIdentity { get; set; }


        //[DataMember]
        ////شماره پذیرنده
        //public string acceptorId { get; set; }



        [DataMember]
        //مقدار
        public string Amount { get; set; }



        [DataMember]

        ////ریسپانس کد
        public string responseCode { get; set; }


    }
}
