﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopWebFormV3.Models
{
    public class BillInfo
    {
        public string BillId { get; set; }
        public string billPaymentId { get; set; }

    }
}
