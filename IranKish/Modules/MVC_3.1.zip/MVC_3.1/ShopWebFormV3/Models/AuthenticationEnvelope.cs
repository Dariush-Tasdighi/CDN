﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopWebFormV3.Models
{
    public class AuthenticationEnvelope
    {

        public string Data { get; set; }
        public string Iv { get; set; }

    }
}
