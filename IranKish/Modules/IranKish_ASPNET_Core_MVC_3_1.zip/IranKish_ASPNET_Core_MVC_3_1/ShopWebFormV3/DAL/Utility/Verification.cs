﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using ShopWebFormV3.DAL.Interface;
using ShopWebFormV3.Models;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Xml;

namespace ShopWebFormV3.DAL.Utility
{
    public class Verification : IVerification 
    {



        public async Task<string> btnVerification_Click(RequestVerify requestVerify) 
        {

            string result = "";

            var client = new HttpClient();

            try
            {

                string request = JsonConvert.SerializeObject(requestVerify);
                var  newrequest = JsonConvert.DeserializeObject(request);
                XmlDocument doc = new XmlDocument();
                doc.Load("DataXmlFile.xml");
                string url = doc.SelectNodes("DocumentElement/BaseAddress/verify")[0].InnerXml.ToString();


                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));



                var response = await client.PostAsJsonAsync(url, newrequest);
                var content = await response.Content.ReadAsStringAsync();

                VerifyResult jResult = JsonConvert.DeserializeObject<VerifyResult>(content);

                if (content!=null)
                {

                   // VerifyResult jResult = JsonConvert.DeserializeObject<VerifyResult>(content);


                    if (jResult.status)
                    {

                        result = "عملیات تایید تراکنش با موفقیت انجام شد";

                    }
                    else
                    {

                        result = "عملیات تایید تراکنش با موفقیت انجام نشد ";

                        

                    }



                }
                else
                {

                    result = jResult.description;

                }


            }
            catch (Exception ex)
            {

                result= ex + "خطا" ;
            }


            return result; 
        
        
        }

      
    }
}
