﻿namespace ShopWebFormV3.Models
{
    public class VerifyResult
    {
        public string responseCode { get; set; }
        public string description { get; set; }
        public bool status { get; set; }
        public SubResult result { get; set; }



    }
}
