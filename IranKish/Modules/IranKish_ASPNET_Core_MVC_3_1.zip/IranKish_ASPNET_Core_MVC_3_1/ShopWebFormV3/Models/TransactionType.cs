﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopWebFormV3.Models
{
    public struct TransactionType
    {

        public const string Purchase = "Purchase";
        public const string Bill = "Bill";
        public const string SpecialBill = "SpecialBill";
    }
}
